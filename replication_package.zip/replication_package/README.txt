----------------------------------------------------------------------------------------------
PLEASE  INSTALL ALL THE PACKAGES USED IN THE BELOW SCRIPTS TO REPLICATE THE EXPERIMENTS
----------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------------------
	MAKE SURE YOU INSTALL THE VERSION OF 'caret' PACKAGE WE HAVE SUPPLIED IN THE replication package.

	The supplied version of 'caret' package has been modified to 
		support p_effort and p_opt performance measures in model testing.

	The supplied 'caret' package is given in caret folder.
---------------------------------------------------------------------------------------------------------------



-------------------------------------------------------------------------------------------------------------------
	
	Run the script files mentioned below through point 1 to 6 in that order to replicate the experiments

------------------------------------------------------------------------------------------------------------------- 


1.	The WPDP.R file contains code to perform 
	within-project defect prediction experiments. 
	The results of this script are saved in extensiveComparison/EXTENSIVE_COMPARISON_FSELECT_CV_wp folder .

2.	The CPDP.R file contains code to perform 
	cross-project defect prediction experiments.
	The results of this script are saved in extensiveComparison/EXTENSIVE_COMPARISON_FSELECT_CV_cp folder
	
3.	The WPDP_BLSMOTE.R file contains code to 
	perform within-project defect prediction experiments 
	on the balanced within-project data from BLSMOTE technique.
	The results of this script are saved in extensiveComparison/EXTENSIVE_COMPARISON_FSELECT_CV_wp_BLSMOTE folder
	
4.	The CPDP_BLSMOTE.R file contains code to 
	perform cross-project defect prediction experiments 
	on the balanced cross-project data from BLSMOTE technique.
	The results of this script are saved in extensiveComparison/EXTENSIVE_COMPARISON_FSELECT_CV_cp_BLSMOTE folder
	
5.	The Ranking.R file contains code to 
	perform Friedmann test, U test,
	to compute average rankings,
	to create demsars significance diagrams and miniboxplots
	from the results of WPDP.R and CPDP.R scripts. 
	Therefore, ensure WPDP.R and CPDP.R scripts have completely executed 
	before Ranking.R script is started.

6.	The Ranking_BLSMOTE.R file contains code to 
	to compute average rankings from the results of WPDP_BLSMOTE.R
	and CPDP_BLSMOTE.R scripts.
	Therefore, ensure WPDP_BLSMOTE.R and CPDP_BLSMOTE.R scripts
	have completely executed before Ranking_BLSMOTE.R script is started.

7.	In the extensivComparison/Reports folder we store the results of
	Ranking.R and Ranking_BSMOTE.R scripts.

8.	The    extensivComparison/eclipse folder,
 	       extensivComparison/equinox folder,
	       extensivComparison/mylyn folder,
               extensivComparison/lucene folder,
               extensivComparison/pde folder,
	hold the datasets of project
	       eclipse,
	       equinox,
	       mylyn,
               lucene,
	       pde    
	respectively.
	These five projects are used as input for 
	WPDP.R , CPDP.R , WPDP_BLSMOTE.R and CPDP_BLSMOTE.R scripts. 
 
	
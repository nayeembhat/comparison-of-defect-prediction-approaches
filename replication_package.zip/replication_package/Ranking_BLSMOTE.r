# THE AVERAGE RANKINGS OF DIFFERENT APPROACHES ARE ALSO COMPUTED IN THIS SCRIPT FILE


rm(list=ls())
library(scmamp)
library(xlsx)
library(ggplot2)

PATHNAME = "extensiveComparison/"

#ONLY THE CROSS-PROJECT AND WITHIN-PROJECT DEFECT PREDICTION EXPERIMENTS WITH BORLINE SMOTE ARE CONSIDERED

context = c("CP_BLSMOTE","WP_BLSMOTE")
# AUC OR ROC PERFORMANCE METRICS IS USED 
# IN COMPUTING AVERAGE RANKINGS
evaluator = c("ROC")

Predictor = c("MOSER","NFIX-ONLY","NR","NFIX+NR","BUG-CAT","BUG-FIX",
              "CK+OO","CK","OO","LOC",
              "HCM","WHCM","EDHCM","LDHCM","LGDHCM",
              "CHU","WCHU","LDCHU","EDCHU","LGDCHU",
              "HH","HWH","LDHH","EDHH","LGDHH")

DATASETNAMES = c("Eclipse","Mylyn","Equinox","PDE","Lucene")



t = 1

for(c in context)
{

  for(e in evaluator)

    {

    FILENAME = paste(PATHNAME,"EXTENSIVE_COMPARISON_FSELECT_CV_",c, sep = "")
    FILENAME = paste(FILENAME,e,paste(c,"avg",e,"glm_BPD_.xlsx",sep = "_"), sep = "/")
    print(FILENAME)
    df = read.xlsx(FILENAME, sheetIndex = 1 )
    df$METRIC = Predictor
    colnames(df) = c("Predictor",DATASETNAMES)

    rankdf  = scmamp::rankMatrix(as.data.frame(t(df[2:6])))
    rankdf = as.data.frame(t(rankdf))


    rankdf$AR = rowMeans(rankdf)

    rankdf = cbind(Predictor,rankdf)
    df$AR = rankdf$AR
    
    
    
    #save average rankings to a file
    fname = paste(PATHNAME,"Reports/",paste(c,"averageRanking",e,"glm_BPD_.xlsx",sep = "_"),sep = "")
    write.xlsx(df, fname,row.names = FALSE)
    
    
  }
  
}  
  
  
  

  
  


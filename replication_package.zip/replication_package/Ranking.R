# THIS SCRIPT FILE IS FOR PERFORMING THE STATISTICAL TESTS LIKE FRIEDMANN TEST, U TEST
# THE AVERAGE RANKINGS OF DIFFERENT APPROACHES ARE ALSO COMPUTED IN THIS SCRIPT FILE
# THE SIGNIFICANCE DIAGRAMS ARE ALSO CREATED THROUGH THIS SCRIPT
# MOREOVER THE MINIBOXPLOTS ARE ALSO CREATED THROUGH THIS FILE


rm(list=ls())
library(scmamp)
library(xlsx)
library(ggplot2)

PATHNAME = "extensiveComparison/"

#ONLY THE CROSS-PROJECT AND WITHIN-PROJECT DEFECT PREDICTION EXPERIMENTS WITHOUT ANY SAMPLING ARE CONSIDERED

context = c("cp","wp")
# POPT, PEFFORT, AND AUC OR ROC PERFORMANCE METRICS ARE USED 
# IN PERFORMING  TESTS, COMPUTING AVERAGE RANKINGS, CREATING SIGNIFICANCE DIAGRAMS OR CREATING MINIBOXPLOTS
evaluator = c("popt","peffort","ROC")

Predictor = c("MOSER","NFIX-ONLY","NR","NFIX+NR","BUG-CAT","BUG-FIX",
              "CK+OO","CK","OO","LOC",
              "HCM","WHCM","EDHCM","LDHCM","LGDHCM",
              "CHU","WCHU","LDCHU","EDCHU","LGDCHU",
              "HH","HWH","LDHH","EDHH","LGDHH")

DATASETNAMES = c("Eclipse","Mylyn","Equinox","PDE","Lucene")

#THIS IS THE LIST OF METRICS WITH HIGHEST MEDIAN PERFORMANCE FROM EACH CATEGORY
#FOR "popt","peffort","ROC" performance metrics respectively
#FOR CROSS-PROJECT CONTEXT AND WITHIN-PROJECT CONTEXT
topers = list(c("MOSER","WHCM","LDCHU","BUG-FIX","LDHH","CK+OO"),     #top performers from six categories of metrics  interms of popt for cross-project context
              c("BUG-CAT","LDHCM","MOSER","CK","EDHH","CHU"),		  #top performers from six categories of metrics interms of peffort for cross-project context 	
              c("MOSER","LDCHU","WHCM","LDHH","CK","BUG-FIX"),		  #top performers from six categories of metrics interms of ROC for cross-project context
              c("MOSER","LDCHU","LDHH","CK+OO","WHCM","BUG-CAT"),	  #top performers from six categories of metrics interms of popt for within-project context 
              c("HWH","LGDCHU","BUG-CAT","CK+OO","MOSER","HCM"),      #top performers from six categories of metrics interms of peffort for within-project context 
              c("MOSER","CK+OO","LGDHH","LDCHU","BUG-CAT","WHCM")	  #top performers from six categories of metrics interms of ROC for within-project context 
)

#function to perform U TEST
wilcoxtest = function(performance,noModels, FOLDS.TOTAL )
{
  
  
  i = 1
  k = noModels + 1    #number of  models plus one
  while(k < (ncol(performance)+2)){
    print("****************************************************************************************")
    print("BPD")   
    print("****************************************************************************************")
    while(i < k)
    {
      j = i + 1
      while(j < k)
      {
        print("x -- vs -- y ---------------- nMCC")
        
        median_x = median(performance[1:FOLDS.TOTAL , i], na.rm = TRUE)
        median_y = median(performance[1:FOLDS.TOTAL , j] , na.rm = TRUE)
        
        print(paste ( median_x, median_y, sep = "  ##  "))
        
        
        #print(wilcox.test(performance[1:FOLDS.TOTAL , i], performance[1:FOLDS.TOTAL , j], alternative = "t"))
        wt = wilcox.test(performance[1:FOLDS.TOTAL , i], performance[1:FOLDS.TOTAL , j], alternative = "t", conf.level = 0.95)
        
        print(wt$p.value)
        print(wt$alternative)
        
        
        
        
        j = j + 1
      }
      
      i = i + 1
    }
    k = k + noModels   #increment by number of models
    
  }
}

t = 1

for(c in context)
{

  for(e in evaluator)

    {

    FILENAME = paste(PATHNAME,"EXTENSIVE_COMPARISON_FSELECT_CV_",c, sep = "")
    FILENAME = paste(FILENAME,e,paste(c,"avg",e,"glm_BPD_.xlsx",sep = "_"), sep = "/")
    print(FILENAME)
    df = read.xlsx(FILENAME, sheetIndex = 1 )
    df$METRIC = Predictor
    colnames(df) = c("Predictor",DATASETNAMES)

    rankdf  = scmamp::rankMatrix(as.data.frame(t(df[2:6])))
    rankdf = as.data.frame(t(rankdf))


    rankdf$AR = rowMeans(rankdf)

    rankdf = cbind(Predictor,rankdf)
    df$AR = rankdf$AR
    
    
    
    # friedman and nemenyi tests
    df2 = as.data.frame(t(df[2:6]))
    colnames(df2) = Predictor
    
    
   test =  friedmanTest(df2)
   print(test)
   print(c)
   print(e)
   print("friedmann ends here")
   
   significance  = 0.05
   if(c == "cp")
     significance  = 0.1
    test = nemenyiTest(df2,alpha = significance)
    
    fname = paste(PATHNAME,"Reports/",paste(c,"cdPLOT",significance * 100,e,"glm_BPD_.jpeg",sep = "_"),sep = "")
   
   # pdf(file = fname,width=9,height = 6, units = 'in', res = 300)
  jpeg(file = fname,width=9,height = 6, units = 'in', res = 300)
  #  tiff(file = fname,width=9,height = 6, units = 'in', res = 300)
    
    plotCD(df2, alpha = significance,cex = 0.6)
    dev.off()
    #save average rankings to a file
    fname = paste(PATHNAME,"Reports/",paste(c,"averageRanking",e,"glm_BPD_.xlsx",sep = "_"),sep = "")
    write.xlsx(df, fname,row.names = FALSE)
    
    
    #mini boxplots
    FILENAME = paste(PATHNAME,"EXTENSIVE_COMPARISON_FSELECT_CV_",c, sep = "")
    FILENAME = paste(FILENAME,e,paste(c,"all",e,"glm_BPD_.xlsx",sep = "_"), sep = "/")
     FILENAME
     
     #read experimental results
    df3  = read.xlsx(FILENAME, sheetIndex = 1 )
    colnames(df3) = Predictor
    
    #compute medians and IQRs and median absolute deviation
    Q1 = c()
    medians  = c()
    Q3 = c()
    MAD = c()
    IQRs  = c()
    
    for(i in 1:ncol(df3))
    {
      fns = fivenum(df3[,i])
    medians[length(medians)+1] = fns[3]  
    Q1[length(Q1)+1] = fns[2]  
    Q3[length(Q3)+1] = fns[4]  
    MAD[length(MAD)+1] = mad(df3[,i])
    IQRs[length(IQRs)+1]  = IQR(df3[,i])
    }
    
    df3.summary = data.frame(Predictor)
   
    
    df3.summary$Q1=Q1
    df3.summary$Medians = medians
    df3.summary$Q3 = Q3
    df3.summary$MAD = MAD
    df3.summary$IQR = IQRs
    #sort based on medians 
    df3.summary = df3.summary[order(-df3.summary$Median),]
    
    ev = e
    if(e  == 'ROC')
    {  ev = "AUC" }
    
    
    ggplot(df3.summary, aes(x= 1:25, y= Medians)) + 
     geom_point(size = 1) +
    geom_linerange(aes(ymin = Q1, ymax = Q3)) +
      xlab("")+ ylab(ev) +
      scale_x_continuous(breaks = 1:25,labels = df3.summary$Predictor) +
      scale_y_continuous(breaks = seq(0.35,0.95,0.05),labels = seq(0.35,0.95,0.05)) +
      
      theme(axis.text = element_text(color = "black",size = 8.5),
        axis.text.x = element_text(angle = 90),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.y = element_line(colour = "grey"),
        panel.background = element_rect(fill = "gray98"),
        axis.title.y = element_text(size = 9, color = "black")
        
         )
    
    
    
   # fname = paste(PATHNAME,"Reports/",paste(c,e,"miniboxplot.pdf",sep = "_"),sep = "")
   # fname = paste(PATHNAME,"Reports/",paste(c,e,"miniboxplot.tiff",sep = "_"),sep = "")
    fname = paste(PATHNAME,"Reports/",paste(c,e,"miniboxplot.jpeg",sep = "_"),sep = "")
   # ggsave(filename = fname)
    ggsave(filename = fname,height = 8, units = "cm",dpi = 300)
    
    
    #wilcoxtest(df3[,topers[[t]]], 6, 250)
    #t = t+1
    print(df3.summary[c(1,2,3,4)])
  }
  
}  
  
  
  